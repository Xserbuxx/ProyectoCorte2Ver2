package co.edu.unbosque.util.exception;

/**
 * Excepción que indica un error en la validación de la fecha de vencimiento.
 */
public class FechaVencimientoException extends Exception {		public FechaVencimientoException(String mensaje) {		super(mensaje);	}
}